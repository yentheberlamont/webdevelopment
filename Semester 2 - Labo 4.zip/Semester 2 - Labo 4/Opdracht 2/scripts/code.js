const setup = () => {
}
window.addEventListener("load", setup);